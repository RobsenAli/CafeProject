package com.perscholas.cafe;

public class Cappuccino extends Product {

	Cappuccino cappuccino = new Cappuccino("Mocha", 4.15, "light brown");
	
	
	
	public Cappuccino() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cappuccino(String name, double price, String description) {
		super(name, price, description);
		// TODO Auto-generated constructor stub
	}

	public double calculateProductTotal() {
		return 0;
	}

}
