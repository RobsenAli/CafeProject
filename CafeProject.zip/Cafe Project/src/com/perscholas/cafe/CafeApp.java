package com.perscholas.cafe;

import java.util.Scanner;

public class CafeApp {

	private static String name;
	private static String description;
	private static double price;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		System.out.println("How many would you like?" + name + description);
		String response = scanner.nextLine();


	}

	public double calculateProductTotal() {
		return 0;
	}

	public static double getPrice() {
		return price;
	}

	public static void setPrice(double price) {
		CafeApp.price = price;
	}

}
