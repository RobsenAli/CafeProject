package com.perscholas.cafe;

public class Espresso extends Product {
	
	

	public Espresso() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Espresso(String name, double price, String description) {
		super(name, price, description);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculateProductTotal() {
		// TODO Auto-generated method stub
		return 0;
	}

}
